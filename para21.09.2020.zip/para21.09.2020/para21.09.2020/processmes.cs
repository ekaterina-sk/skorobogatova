﻿using System;
using System.Collections.Generic;
using System.Text;

namespace para21._09._2020
{
    class processmes
    {
        List<Process> processes = new List<Process>();

        public int count
        {
            get;
            private set;
        }
        private int [] array;
        public void Add(int element)
        {
            //processes.Add(i);
            //return;
            try
            {
                array[count] = element;
                count++;
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public int Size()
        {
            return count;
        }
        public void Delete(int place)
        {
            //processes.Remove(i);
            //return;
            for (int i = place; i != Size(); i++)
            {
                array[i] = array[i + 1];
            }
            array[count] = default(int);
            count--;
        }

        public void Clear()
        {
            processes.Clear();
            return;
        }

        public void Sort(List<int> spisok)
        {
            spisok.Sort();
            return;
        }
    }
}

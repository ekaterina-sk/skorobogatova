﻿using System;
using System.Collections.Generic;
using System.Text;

namespace para21._09._2020
{
    class Process
    {
        int id;
        string Name;
        int TimeUsed;


       
    }
}

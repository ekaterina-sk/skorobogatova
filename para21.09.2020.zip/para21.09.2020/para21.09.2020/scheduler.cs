﻿using System;
using System.Collections.Generic;
using System.Text;

namespace para21._09._2020
{
    class scheduler
    {
        GetNextActive(List<Process> procs);

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace para21._09._2020
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
